setwd("C:\\Users\\it24103260\\Desktop\\IT24103260_Lab5")

Delivery_Times <- read.table("Data.txt", header = TRUE, sep = ",")

shareholder_hist <- hist(Delivery_Times$Number_of_Shareholders.thousands.,
                         breaks = seq(130, 270, length.out = 10),
                         right = FALSE,
                         main = "Histogram for Number of Shareholders",
                         xlab = "Number of Shareholders (thousands)")

freq <- shareholder_hist$counts
breaks <- shareholder_hist$breaks

# [cite_start]Next, we calculate the cumulative frequencies. [cite: 67]
cum_freq <- cumsum(freq)

# [cite_start]We prepare the data vector for the ogive plot. [cite: 68, 69, 70]
ogive_data <- c(0, cum_freq)

dev.off()

plot(breaks, ogive_data,
     type = "b", # "b" plots both points and lines
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Number of Shareholders (thousands)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum_freq)))
